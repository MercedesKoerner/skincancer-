op_version_set = 1
class MyResnet(Module):
  __parameters__ = []
  training : bool
  resnet : __torch__.torchvision.models.resnet.ResNet
  def forward(self: __torch__.MyResnet,
    x: Tensor) -> Tensor:
    return (self.resnet).forward(x, )
