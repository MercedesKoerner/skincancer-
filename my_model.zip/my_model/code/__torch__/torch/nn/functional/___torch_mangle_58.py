op_version_set = 1
def pad(input: Tensor,
    pad: List[int],
    mode: str="constant",
    value: float=0.) -> Tensor:
  _0 = __torch__.torch.nn.functional.___torch_mangle_59._pad_circular
  _1 = __torch__.torch.nn.functional.___torch_mangle_60._pad_circular
  _2 = __torch__.torch.nn.functional.___torch_mangle_61._pad_circular
  _3 = uninitialized(Tensor)
  _4 = torch.eq(torch.remainder(torch.len(pad), 2), 0)
  if _4:
    pass
  else:
    ops.prim.RaiseException("Exception")
  _5 = torch.le(torch.floordiv(torch.len(pad), 2), torch.dim(input))
  if _5:
    pass
  else:
    ops.prim.RaiseException("Exception")
  if torch.eq(mode, "constant"):
    _6 = torch.constant_pad_nd(input, pad, value)
  else:
    if torch.eq(value, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.eq(torch.dim(input), 3):
      if torch.eq(torch.len(pad), 2):
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq(mode, "reflect"):
        _8 = torch.reflection_pad1d(input, pad)
      else:
        if torch.eq(mode, "replicate"):
          _9 = torch.replication_pad1d(input, pad)
        else:
          if torch.eq(mode, "circular"):
            _10 = _0(input, pad, )
          else:
            ops.prim.RaiseException("Exception")
            _10 = _3
          _9 = _10
        _8 = _9
      _7 = _8
    else:
      if torch.eq(torch.dim(input), 4):
        if torch.eq(torch.len(pad), 4):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(mode, "reflect"):
          _12 = torch.reflection_pad2d(input, pad)
        else:
          if torch.eq(mode, "replicate"):
            _13 = torch.replication_pad2d(input, pad)
          else:
            if torch.eq(mode, "circular"):
              _14 = _1(input, pad, )
            else:
              ops.prim.RaiseException("Exception")
              _14 = _3
            _13 = _14
          _12 = _13
        _11 = _12
      else:
        if torch.eq(torch.dim(input), 5):
          if torch.eq(torch.len(pad), 6):
            pass
          else:
            ops.prim.RaiseException("Exception")
          if torch.eq(mode, "reflect"):
            ops.prim.RaiseException("Exception")
            _16 = _3
          else:
            if torch.eq(mode, "replicate"):
              _17 = torch.replication_pad3d(input, pad)
            else:
              _18 = torch.eq(mode, "circular")
              if _18:
                _19 = _2(input, pad, )
              else:
                ops.prim.RaiseException("Exception")
                _19 = _3
              _17 = _19
            _16 = _17
          _15 = _16
        else:
          ops.prim.RaiseException("Exception")
          _15 = _3
        _11 = _15
      _7 = _11
    _6 = _7
  return _6
