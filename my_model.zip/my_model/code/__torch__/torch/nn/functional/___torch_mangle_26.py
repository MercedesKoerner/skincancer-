op_version_set = 1
def _pad_circular(input: Tensor,
    padding: List[int]) -> Tensor:
  _0 = torch.slice(input, 0, 0, 9223372036854775807, 1)
  _1 = torch.slice(_0, 1, 0, 9223372036854775807, 1)
  _2 = [input, torch.slice(_1, 2, 0, padding[-1], 1)]
  input0 = torch.cat(_2, 2)
  _3 = torch.slice(input0, 0, 0, 9223372036854775807, 1)
  _4 = torch.slice(_3, 1, 0, 9223372036854775807, 1)
  _5 = torch.neg(torch.add(padding[-1], padding[-2]))
  _6 = torch.slice(_4, 2, _5, torch.neg(padding[-1]), 1)
  input1 = torch.cat([_6, input0], 2)
  if torch.gt(torch.len(padding), 2):
    _7 = torch.slice(input1, 0, 0, 9223372036854775807, 1)
    _8 = torch.slice(_7, 1, 0, 9223372036854775807, 1)
    _9 = torch.slice(_8, 2, 0, 9223372036854775807, 1)
    _10 = torch.slice(_9, 3, 0, padding[-3], 1)
    input3 = torch.cat([input1, _10], 3)
    _11 = torch.slice(input3, 0, 0, 9223372036854775807, 1)
    _12 = torch.slice(_11, 1, 0, 9223372036854775807, 1)
    _13 = torch.slice(_12, 2, 0, 9223372036854775807, 1)
    _14 = torch.neg(torch.add(padding[-3], padding[-4]))
    _15 = torch.slice(_13, 3, _14, torch.neg(padding[-3]), 1)
    input2 = torch.cat([_15, input3], 3)
  else:
    input2 = input1
  if torch.gt(torch.len(padding), 4):
    _16 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
    _17 = torch.slice(_16, 1, 0, 9223372036854775807, 1)
    _18 = torch.slice(_17, 2, 0, 9223372036854775807, 1)
    _19 = torch.slice(_18, 3, 0, 9223372036854775807, 1)
    _20 = torch.slice(_19, 4, 0, padding[-5], 1)
    input5 = torch.cat([input2, _20], 4)
    _21 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
    _22 = torch.slice(_21, 1, 0, 9223372036854775807, 1)
    _23 = torch.slice(_22, 2, 0, 9223372036854775807, 1)
    _24 = torch.slice(_23, 3, 0, 9223372036854775807, 1)
    _25 = torch.neg(torch.add(padding[-5], padding[-6]))
    _26 = torch.slice(_24, 4, _25, torch.neg(padding[-5]), 1)
    input4 = torch.cat([_26, input5], 4)
  else:
    input4 = input2
  return input4
