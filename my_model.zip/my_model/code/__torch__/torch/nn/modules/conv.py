op_version_set = 1
class Conv2d(Module):
  __parameters__ = ["weight", ]
  weight : Tensor
  training : bool
  transposed : bool
  def forward(self: __torch__.torch.nn.modules.conv.Conv2d,
    input: Tensor) -> Tensor:
    _0 = (self).conv2d_forward(input, self.weight, )
    return _0
  def conv2d_forward(self: __torch__.torch.nn.modules.conv.Conv2d,
    input: Tensor,
    weight: Tensor) -> Tensor:
    _1 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _4 = torch.floordiv(torch.add(3, 1), 2)
      _5 = torch.floordiv(3, 2)
      _6 = torch.floordiv(torch.add(3, 1), 2)
      _7 = [_4, _5, _6, torch.floordiv(3, 2)]
      _8 = __torch__.torch.nn.functional.pad(input, _7, "circular", 0., )
      _9 = [0, 0]
      _2, _3 = True, torch.conv2d(_8, weight, None, [2, 2], _9, [1, 1], 1)
    else:
      _2, _3 = False, _1
    if _2:
      _10 = _3
    else:
      _10 = torch.conv2d(input, weight, None, [2, 2], [3, 3], [1, 1], 1)
    return _10
